// angular import
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Project import
import { AdminComponent } from './theme/layouts/admin-layout/admin-layout.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        redirectTo: '/dashboard/reports',
        pathMatch: 'full'
      },
      {
        path: 'dashboard/reports',
        loadComponent: () => import('./demo/pages/dashboard/reports/default.component').then((c) => c.DefaultComponent)
      },
      {
        path: 'dashboard/search-import',
        loadComponent: () => import('./demo/pages/dashboard/search-and-import/search-and-import.component').then((c) => c.SearchAndImportComponent)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
