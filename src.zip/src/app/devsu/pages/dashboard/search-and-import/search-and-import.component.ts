import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr'; // opcional si usas alertas
import { CharacterService } from '../services/charater.service';
@Component({
  selector: 'app-search-and-import',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, HttpClientModule],
  templateUrl: './search-and-import.component.html',
  styleUrl: './search-and-import.component.scss'
})
export class SearchAndImportComponent {
  private fb = inject(FormBuilder);
  private characterService = inject(CharacterService);
  private toastr = inject(ToastrService);

  searchForm: FormGroup;
  characters: any[] = [];
  loading = false;

  constructor() {
    this.searchForm = this.fb.group({
      name: ['', Validators.required]
    });
  }

  searchCharacters(): void {
    if (this.searchForm.invalid) return;

    const name = this.searchForm.value.name;
    this.loading = true;

    this.characterService.searchByName(name).subscribe({
      next: (results) => {
        this.characters = results;
        this.loading = false;
      },
      error: (err) => {
        this.toastr.error('Error al buscar personajes');
        this.loading = false;
      }
    });
  }

  importCharacters(id:String): void {
    // lógica para importar a backend
    this.toastr.info("Realizando importación ℹ️")
    this.characterService.import(id).subscribe({
      next: (results) => {
        this.toastr.success('Importación realizada');
      },
      error: (err) => {
        this.toastr.error('Error al importar personaje');
      }
    });
  }
}
