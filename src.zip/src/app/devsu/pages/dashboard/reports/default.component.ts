// angular import
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IconService, IconDirective } from '@ant-design/icons-angular';
import { FallOutline, GiftOutline, MessageOutline, RiseOutline, SettingOutline } from '@ant-design/icons-angular/icons';
import { CharacterService } from '../services/charater.service';
import { ToastrService } from 'ngx-toastr'; // opcional si usas alertas

@Component({
  selector: 'app-default',
  imports: [
    CommonModule
  ],
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.scss']
})
export class DefaultComponent {
  private iconService = inject(IconService);
  private characterService = inject(CharacterService);
  public charactersInOrderAsc: any;
  public getCharacterCountPerEpisode: any;
  public getAllLocationsWithCharacters: any;
  public loading = false;
  private toastr = inject(ToastrService);

  // constructor
  constructor() {
    this.searchCharacters()
  }

  searchCharacters(): void {
    this.loading = true;
    this.characterService.staticReports().subscribe({
      next: (results:any) => {
        this.charactersInOrderAsc = results.charactersInOrderAsc
        this.getAllLocationsWithCharacters = results.getAllLocationsWithCharacters
        this.getCharacterCountPerEpisode = results.getCharacterCountPerEpisode
        this.loading = false;

      },

      error: (err) => {
        this.toastr.error('Error al buscar personajes');
        this.loading = false;
      }
      
    })
  }
}
