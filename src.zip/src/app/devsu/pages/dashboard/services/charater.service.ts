import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CharacterService {
  private apiUrl = `${environment.apiUrl}/characters`;

  constructor(private http: HttpClient) {}

  searchByName(name: string): Observable<any[]> {
    let body = {
      name 
    }

    return this.http.post<any[]>(`${this.apiUrl}/search`,body);
  }

  import(id: String): Observable<any[]> {
    let body = {
      id: id.toString()
    }

    return this.http.post<any[]>(`${this.apiUrl}/import`,body);
  }

  staticReports(): Observable<any[]> {

    return this.http.get<any[]>(`${this.apiUrl}/reports/statics`);
  }
}
